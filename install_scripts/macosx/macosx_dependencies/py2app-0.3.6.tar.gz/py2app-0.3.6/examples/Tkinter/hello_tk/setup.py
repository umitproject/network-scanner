from setuptools import setup

setup(
    app=['hello.py'],
    setup_requires=["py2app"],
)
