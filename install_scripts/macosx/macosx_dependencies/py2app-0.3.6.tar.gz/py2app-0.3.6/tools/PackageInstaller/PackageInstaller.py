"""
Create a package from a setup.py
"""

from bdist_mpkg.scripts.script_bdist_mpkg import main
main()
